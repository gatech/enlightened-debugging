/* 
 * Copyright 2019 Georgia Institute of Technology
 * All rights reserved.
 *
 * Author(s): Xiangyu Li <xiangyu.li@cc.gatech.edu>
 *
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package anonymous.domain.enlighten.legacy;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import anonymous.domain.enlighten.data.ExecutionProfile;
import anonymous.domain.enlighten.data.MethodInvocation;
import anonymous.domain.enlighten.data.MethodName;
import anonymous.domain.enlighten.subjectmodel.SubjectProgram;

public class FaultyMethodInvocation {
  
  private ExecutionProfile profile;
  
  private MethodName faultyMethod;
  
  private boolean isFaultyMethodInvoked;
  private List<MethodInvocation> previous;
  
  public static void main(String[] args) throws IOException {
    String[] subjectNames = {
        "jtopas-v1-fault2/faulty", 
        "jtopas-v1-fault5/faulty", 
        "jtopas-v1-fault6/faulty" };
    for (String subjectName : subjectNames) {
      SubjectProgram subject = SubjectProgram.openSubjectProgram(
          Paths.get("subjects", subjectName), Paths.get("out", subjectName));
      Path executionProfileDir = subject.getExecutionProfileDir();
      File[] profiles = executionProfileDir.toFile().listFiles(new FilenameFilter() {

        @Override
        public boolean accept(File dir, String name) {
          return name.endsWith(".profile");
        }
      });
      for (File profileFile : profiles) {
        System.out.println("============Begin " + subjectName + ":" + profileFile.getName() + "===============");
        ExecutionProfile profile = ExecutionProfile.readFromDataFile(profileFile.toPath());
        new FaultyMethodInvocation(subject, profile).printUndecidedCalls();
        System.out.println("============End " + subjectName + ":" + profileFile.getName() + "===============");
      }
    }
  }
  
  public FaultyMethodInvocation(SubjectProgram subject, ExecutionProfile profile) {
    this.profile = profile;
    faultyMethod = MethodName.get(
        subject.getFaultyClassName(), subject.getFaultyMethodSignature());
    isFaultyMethodInvoked = false;
  }

  public void printUndecidedCalls() {
    traverse(profile.getInvocationTreeRoot());
  }
  
  private void traverse(MethodInvocation node) {
    MethodName methodName = node.getMethodName();
    if (methodName.equals(faultyMethod)) {
      if (isFaultyMethodInvoked) {
        System.out.print("{");
        MethodInvocation itr = node;
        while (itr != null) {
          if (!previous.contains(itr)) {
            System.out.print(itr.getMethodName().toString() + ", ");
          }
          itr = itr.getEnclosingInvocation();
        }
        System.out.println("}");
      } else {
        isFaultyMethodInvoked = true;
        previous = new ArrayList<>();
        MethodInvocation itr = node;
        while (itr != null) {
          previous.add(itr);
          itr = itr.getEnclosingInvocation();
        }
      }
    }
    for (MethodInvocation invoked : node.getEnclosedInvocations()) {
      traverse(invoked);
    }
  }
}
